# DO NOT CHANGE OR REMOVE THIS COMMENT, and do not change this import otherwise all tests will fail.
from blackjack_helper import *

# Write all of your part 3 code below this comment. DO NOT CHANGE OR REMOVE THIS COMMENT.
hand_value = draw_starting_hand('your')
if hand_value >= 21:
    print_end_turn_status(hand_value)
else:
    deal_again = input('You have {}. Hit (y/n)? '.format(hand_value))
    while deal_again != 'y' and deal_again != 'n':
        print("Sorry I didn't get that.")
        deal_again = input('You have {}. Hit (y/n)? '.format(hand_value))
    while hand_value < 21 and deal_again == 'y':
        if deal_again != 'y' and deal_again != 'n':
            print("Sorry I didn't get that.")
            deal_again = input('You have {}. Hit (y/n)? '.format(hand_value))
        hand_value = hand_value + draw_card()
        if hand_value < 21:
            deal_again = input('You have {}. Hit (y/n)? '.format(hand_value))
        while deal_again != 'y' and deal_again != 'n':
            print("Sorry I didn't get that.")
            deal_again = input('You have {}. Hit (y/n)? '.format(hand_value))
    if hand_value == 21:
        print_end_turn_status(hand_value)
    elif hand_value > 21:
        print_end_turn_status(hand_value)
    if deal_again == 'n' and hand_value < 21:
        print_end_turn_status(hand_value)
user_hand = hand_value
hand_value = draw_starting_hand('dealer')
while hand_value < 17:
    print('Dealer has {}.'.format(hand_value))
    hand_value = hand_value + draw_card()
print_end_turn_status(hand_value)
dealer_hand = hand_value
print_end_game_status(user_hand, dealer_hand)
