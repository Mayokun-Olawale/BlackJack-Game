from unittest import TestCase, main
from unittest.mock import patch
from test_helper import run_test

class TestBlackjack(TestCase):

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_example(self, input_mock, randint_mock):
        '''
        Both the dealer and user receive cards that end up with a hand less than 21.
        The dealer wins by having a higher hand than the user.

        This does not count as one of your tests.
        '''
        output = run_test([3, 5, 8], ['y', 'n'], [3, 5, 10], randint_mock, input_mock)
        expected = "-----------\n" \
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 3\n" \
                   "Drew a 5\n" \
                   "You have 8. Hit (y/n)? y\n" \
                   "Drew an 8\n" \
                   "You have 16. Hit (y/n)? n\n" \
                   "Final hand: 16.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a 3\n" \
                   "Drew a 5\n" \
                   "Dealer has 8.\n" \
                   "Drew a 10\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)

    # Make sure all your test functions start with test_ 
    # Follow indentation of test_example
    # WRITE ALL YOUR TESTS BELOW. Do not delete this line.

    '''
    Both the user and dealer end up with handvalues less than 21
    The user's handvalue is greater than the dealer, so the user wins.
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_under_21_user_win(self, input_mock, randint_mock):
        output = run_test([1, 7], ['n'], [8, 9], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a 7\n" \
                   "You have 18. Hit (y/n)? n\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew an 8\n" \
                   "Drew a 9\n" \
                   "Final hand: 17.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "You win!\n"
        self.assertEqual(output, expected) 

    '''
    Both the user and dealer have handvalues less than 21
    The dealer's handvalue is greater than the user, so the dealer wins.
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_under_21_dealer_win(self, input_mock, randint_mock):
        output = run_test([2, 5, 6], ['y', 'n'], [13, 10], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 2\n" \
                   "Drew a 5\n" \
                   "You have 7. Hit (y/n)? y\n" \
                   "Drew a 6\n" \
                   "You have 13. Hit (y/n)? n\n" \
                   "Final hand: 13.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a King\n" \
                   "Drew a 10\n" \
                   "Final hand: 20.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)

    '''
    Both the user and dealer have a handvalue less than 21
    They end up with the same value and the result is Push.
    '''
    
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_under_21_push(self, input_mock, randint_mock):
        output = run_test([5, 2, 11, 3], ['x', 'y', 'q', 'z', 'y', 'n'], [12, 5, 5], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 5\n" \
                   "Drew a 2\n" \
                   "You have 7. Hit (y/n)? x\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 7. Hit (y/n)? y\n" \
                   "Drew a Jack\n" \
                   "You have 17. Hit (y/n)? q\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 17. Hit (y/n)? z\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 17. Hit (y/n)? y\n" \
                   "Drew a 3\n"\
                   "You have 20. Hit (y/n)? n\n" \
                   "Final hand: 20.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a Queen\n" \
                   "Drew a 5\n" \
                   "Dealer has 15.\n"\
                   "Drew a 5\n" \
                   "Final hand: 20.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Push.\n"
        self.assertEqual(output, expected)

    '''
    Both user and dealer a final handvalue of 21 which will result in a Push. 
    In this particular test, the user will get blackjack with the first hand
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_both_blackjack_user_intialhand(self, input_mock, randint_mock):
        output = run_test([1, 11], [], [6, 5, 4, 6], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a Jack\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a 6\n" \
                   "Drew a 5\n" \
                   "Dealer has 11.\n"\
                   "Drew a 4\n" \
                   "Dealer has 15.\n"\
                   "Drew a 6\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Push.\n"
        self.assertEqual(output, expected)
    
    '''
    Both the dealer and user have a final handvalue of 21.
    They both get Blackjack and the game ends with a push. In this test, the user responds 'y' to the question 'should hit?'
    '''

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_both_blackjack_user_shouldhit_yes(self, input_mock, randint_mock):
        output = run_test([2, 8, 3, 5, 3], ['y', 'y', 'y'], [1, 13], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 2\n" \
                   "Drew an 8\n" \
                   "You have 10. Hit (y/n)? y\n" \
                   "Drew a 3\n" \
                   "You have 13. Hit (y/n)? y\n" \
                   "Drew a 5\n" \
                   "You have 18. Hit (y/n)? y\n" \
                   "Drew a 3\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a King\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Push.\n"
        self.assertEqual(output, expected)
    
    '''
    Both the user and dealer have a handvalue of 21.
    They both get blackjack and the game ends with a Push. In this test, the user inputs invalid charcters when asked "should hit".
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_both_blackjack_user_invalid_input(self, input_mock, randint_mock):
        output = run_test([1, 2, 3, 2, 3], ['x', 'y', 'q', 'y', 'z', 'y'], [11, 1], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a 2\n" \
                   "You have 13. Hit (y/n)? x\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 13. Hit (y/n)? y\n" \
                   "Drew a 3\n" \
                   "You have 16. Hit (y/n)? q\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 16. Hit (y/n)? y\n" \
                   "Drew a 2\n"\
                   "You have 18. Hit (y/n)? z\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 18. Hit (y/n)? y\n" \
                   "Drew a 3\n"\
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a Jack\n" \
                   "Drew an Ace\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Push.\n"
        self.assertEqual(output, expected)
    
    '''
    The user's handvalue is 21 and the dealer is over 21 which is Bust.
    The user wins because the final handvalue is blackjack and the dealer busts.
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_user_blackjack_dealer_bust(self, input_mock, randint_mock):
        output = run_test([1, 11], [], [15, 1], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a Jack\n" \
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "BAD CARD\n" \
                   "Drew an Ace\n" \
                   "Final hand: 26.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "You win!\n"
        self.assertEqual(output, expected)

    '''
    Both the user and dealer have handvalue under 21. 
    The user value is greater which means the user wins. In this test, the user answers the "should hit" question with invalid inputs.
    '''

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_under_21_user_invalid_input(self, input_mock, randint_mock):
        output = run_test([1, 6, 2], ['q', 'r', 'y', '$', 'n'], [10, 8], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a 6\n" \
                   "You have 17. Hit (y/n)? q\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 17. Hit (y/n)? r\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 17. Hit (y/n)? y\n" \
                   "Drew a 2\n" \
                   "You have 19. Hit (y/n)? $\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 19. Hit (y/n)? n\n" \
                   "Final hand: 19.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a 10\n" \
                   "Drew an 8\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "You win!\n"
                
        self.assertEqual(output, expected)

    '''
    The user has the handvalue of 21 and the dealer has  a handvalue less than 21.
    The user wins because it got a blackjack and the dealer has less than 21.
    '''

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_user_blackjack_dealer_less(self, input_mock, randint_mock):
        output = run_test([3, 7, 4, 2, 5], ['y', 'y', '<', '10', 'y'], [10, 2, 6], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 3\n" \
                   "Drew a 7\n" \
                   "You have 10. Hit (y/n)? y\n" \
                   "Drew a 4\n" \
                   "You have 14. Hit (y/n)? y\n" \
                   "Drew a 2\n"\
                   "You have 16. Hit (y/n)? <\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 16. Hit (y/n)? 10\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 16. Hit (y/n)? y\n" \
                   "Drew a 5\n"\
                   "Final hand: 21.\n" \
                   "BLACKJACK!\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a 10\n" \
                   "Drew a 2\n" \
                   "Dealer has 12.\n" \
                   "Drew a 6\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "You win!\n"
        self.assertEqual(output, expected)

    '''
    The user's handvalue is over 21 while the dealers handvalue is under 21.
    The dealer wins because the user busts.
    '''

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_user_bust_dealer_under_21(self, input_mock, randint_mock):
        output = run_test([13, 15], [], [1, 7], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a King\n" \
                   "BAD CARD\n" \
                   "Final hand: 25.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew a 7\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
                
        self.assertEqual(output, expected)

    '''
    The user bust while the dealer is under 21.
    The dealer wins because the user busts. In this test, the user is going to respond with both invalid answers and 'y' to the question "should hit".
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_user_bust_dealer_less(self, input_mock, randint_mock):
        output = run_test([5, 6, 2, 3, 4, 1], ['y', 'y', '#', 'y', '@', 'y'], [5, 6, 7], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 5\n" \
                   "Drew a 6\n" \
                   "You have 11. Hit (y/n)? y\n" \
                   "Drew a 2\n" \
                   "You have 13. Hit (y/n)? y\n" \
                   "Drew a 3\n"\
                   "You have 16. Hit (y/n)? #\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 16. Hit (y/n)? y\n" \
                   "Drew a 4\n" \
                   "You have 20. Hit (y/n)? @\n" \
                   "Sorry I didn't get that.\n"\
                   "You have 20. Hit (y/n)? y\n" \
                   "Drew an Ace\n"\
                   "Final hand: 31.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a 5\n" \
                   "Drew a 6\n" \
                   "Dealer has 11.\n" \
                   "Drew a 7\n" \
                   "Final hand: 18.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)

    '''
    Both the user and the dealer bust.
    The dealer wins because the user busts.
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_user_bust_dealer_bust(self, input_mock, randint_mock):
        output = run_test([13, 5, 12], [':)', 'y'], [11, 6, 1], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a King\n" \
                   "Drew a 5\n" \
                   "You have 15. Hit (y/n)? :)\n" \
                   "Sorry I didn't get that.\n" \
                   "You have 15. Hit (y/n)? y\n" \
                   "Drew a Queen\n" \
                   "Final hand: 25.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a Jack\n" \
                   "Drew a 6\n" \
                   "Dealer has 16.\n" \
                   "Drew an Ace\n" \
                   "Final hand: 27.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)

    '''
    Both the user and the dealer bust, however both have the same handvalue.
    The dealer wins because the user busts.
    '''

    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_both_bust_and_equal(self, input_mock, randint_mock):
        output = run_test([12, 13, 7], ['y'], [13, 6, 1], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a Queen\n" \
                   "Drew a King\n" \
                   "You have 20. Hit (y/n)? y\n" \
                   "Drew a 7\n" \
                   "Final hand: 27.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew a King\n" \
                   "Drew a 6\n" \
                   "Dealer has 16.\n" \
                   "Drew an Ace\n" \
                   "Final hand: 27.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)

    '''
    Both the user and dealer bust, they also have the same handvalue.
    The dealer wins because the user bust. In this test, the user inputs invalid variables to the question "should hit".
    '''
    @patch('blackjack_helper.randint')
    @patch('builtins.input')
    def test_both_bust_and_equal_invalid_input(self, input_mock, randint_mock):
        output = run_test([4, 3, 12, 5], ['&', 'y', '%', '333', 'y'], [1, 1], randint_mock, input_mock)
        expected = "-----------\n"\
                   "YOUR TURN\n" \
                   "-----------\n" \
                   "Drew a 4\n" \
                   "Drew a 3\n" \
                   "You have 7. Hit (y/n)? &\n" \
                   "Sorry I didn't get that.\n" \
                   "You have 7. Hit (y/n)? y\n" \
                   "Drew a Queen\n" \
                   "You have 17. Hit (y/n)? %\n" \
                   "Sorry I didn't get that.\n" \
                   "You have 17. Hit (y/n)? 333\n" \
                   "Sorry I didn't get that.\n" \
                   "You have 17. Hit (y/n)? y\n" \
                   "Drew a 5\n" \
                   "Final hand: 22.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "DEALER TURN\n" \
                   "-----------\n" \
                   "Drew an Ace\n" \
                   "Drew an Ace\n" \
                   "Final hand: 22.\n" \
                   "BUST.\n" \
                   "-----------\n" \
                   "GAME RESULT\n" \
                   "-----------\n" \
                   "Dealer wins!\n"
        self.assertEqual(output, expected)







    # Write all your tests above this. Do not delete this line.

if __name__ == '__main__':
    main()
